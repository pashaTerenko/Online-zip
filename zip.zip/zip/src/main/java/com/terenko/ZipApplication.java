package com.terenko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZipApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZipApplication.class, args);
    }

}
